/* =====================================================================
   Codelli — ponte nativa (Supabase)
   Implementa as mesmas funções que o protótipo usava (db, user, sample)
   e troca as contas locais por login real com e-mail (Supabase Auth).
   ===================================================================== */
(function(){
  const cfg = window.CODELLI_CONFIG;
  const sb = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false, flowType: "pkce" }
  });
  window.sb = sb;
  let session = null, profile = null;

  /* ---------- caminhos estilo "coleção/documento" sobre o Postgres ---------- */
  // events/{uid}            -> tabela visitors      (perfil do visitante)
  // events/{uid}/log/{id}   -> tabela events        (cada ação)
  // qualquer outro caminho  -> tabela docs          (config, imagens, dados do usuário)
  const isEvLog = p => /^events\/[^/]+\/log\/[^/]+$/.test(p);
  const isEvProfile = p => /^events\/[^/]+$/.test(p);
  const parentOf = p => p.split("/").slice(0,-1).join("/");
  function snap(path, data){ return { id: path.split("/").pop(), exists: !!data, data: () => data ? JSON.parse(JSON.stringify(data)) : undefined, ref:{path} }; }

  function docRef(path){
    return {
      path,
      async get(){
        if(isEvLog(path)){ const id=path.split("/").pop(); const {data}=await sb.from("events").select("raw").eq("id",id).maybeSingle(); return snap(path, data?.raw); }
        if(isEvProfile(path)){ const uid=path.split("/")[1]; const {data}=await sb.from("visitors").select("*").eq("uid",uid).maybeSingle(); return snap(path, data); }
        const {data,error}=await sb.from("docs").select("data").eq("path",path).maybeSingle(); if(error) throw err(error); return snap(path, data?.data);
      },
      async set(obj){
        if(isEvLog(path)){ const uid=path.split("/")[1], e=obj;
          const row={ id:e.id, uid, type:e.type, acct:e.acct||null, name:e.name||null, pid:e.pid||null, store:e.store||null, price:e.price||null, q:e.q||null, owner_action:!!e.owner, created_at:new Date(e.t||Date.now()).toISOString(), raw:e };
          const {error}=await sb.from("events").insert(row); if(error) throw err(error); return; }
        if(isEvProfile(path)){ const uid=path.split("/")[1]; const {error}=await sb.from("visitors").upsert({uid, acct:obj.acct||null, name:obj.name||null, last_seen:new Date().toISOString(), ua:obj.ua||null}); if(error) throw err(error); return; }
        const {error}=await sb.from("docs").upsert({path, parent:parentOf(path), data:obj}); if(error) throw err(error);
      },
      async update(obj){ const cur=(await this.get()).data()||{}; return this.set({...cur,...obj}); },
      async delete(){
        if(isEvLog(path)){ await sb.from("events").delete().eq("id",path.split("/").pop()); return; }
        const {error}=await sb.from("docs").delete().eq("path",path); if(error) throw err(error);
      },
      onSnapshot(next, onErr){
        let alive=true;
        this.get().then(s=>alive&&next(s)).catch(e=>onErr&&onErr(e));
        const ch = sb.channel("doc:"+path).on("postgres_changes",{event:"*",schema:"public",table:"docs",filter:`path=eq.${path}`},()=>{ this.get().then(s=>alive&&next(s)).catch(()=>{}); }).subscribe();
        return ()=>{ alive=false; sb.removeChannel(ch); };
      }
    };
  }
  function query(coll, opts={}){
    const q = { coll, _order:opts._order||null, _limit:opts._limit||500 };
    q.orderBy=(field,dir="asc")=>query(coll,{...q,_order:{field,dir}});
    q.limit=n=>query(coll,{...q,_limit:n});
    q.get=async()=>{
      if(coll==="events"){ const {data,error}=await sb.from("visitors").select("*").order("last_seen",{ascending:false}).limit(q._limit); if(error) throw err(error); return {docs:data.map(v=>snap("events/"+v.uid, v)), size:data.length}; }
      const m=coll.match(/^events\/([^/]+)\/log$/);
      if(m){ const {data,error}=await sb.from("events").select("raw").eq("uid",m[1]).order("created_at",{ascending:false}).limit(q._limit); if(error) throw err(error); return {docs:data.map(r=>snap(coll+"/"+r.raw.id, r.raw)), size:data.length}; }
      const {data,error}=await sb.from("docs").select("path,data").eq("parent",coll).limit(q._limit); if(error) throw err(error);
      return {docs:data.map(r=>snap(r.path,r.data)), size:data.length};
    };
    q.onSnapshot=(next,onErr)=>{ let alive=true; const run=()=>q.get().then(s=>alive&&next(s)).catch(e=>onErr&&onErr(e)); run();
      const ch=sb.channel("coll:"+coll).on("postgres_changes",{event:"*",schema:"public",table:"docs",filter:`parent=eq.${coll}`},run).subscribe();
      return ()=>{ alive=false; sb.removeChannel(ch); }; };
    return q;
  }
  function err(e){ const x=new Error(e.message||"Erro no servidor"); x.code = /permission|policy|rls/i.test(e.message||"") ? "permission_denied" : "server_error"; return x; }
  const db = { doc: docRef, collection: query };

  /* ---------- usuário ---------- */
  const user = {
    id: async()=> session?.user?.id || null,
    isOwner: async()=> !!profile?.is_owner
  };

  /* ---------- Delli (IA) via função no servidor: a chave nunca fica no app ---------- */
  async function sample(turns, opts={}){
    const {data:{session:s}} = await sb.auth.getSession();
    const res = await fetch(cfg.SUPABASE_URL+"/functions/v1/delli-chat", {
      method:"POST",
      headers:{ "Content-Type":"application/json", "apikey":cfg.SUPABASE_ANON_KEY, "Authorization":"Bearer "+(s?.access_token||cfg.SUPABASE_ANON_KEY) },
      body: JSON.stringify({ turns })
    });
    if(res.status===429){ const e=new Error("rate"); e.code="rate_limited"; throw e; }
    if(!res.ok){ const e=new Error("Delli indisponível"); e.code="server_error"; e.text="A Delli não conseguiu responder agora."; throw e; }
    const reader=res.body.getReader(), dec=new TextDecoder(); let text="";
    for(;;){ const {done,value}=await reader.read(); if(done) break; text+=dec.decode(value,{stream:true}); opts.onText && opts.onText({text}); }
    return { text };
  }

  /* ---------- conta do cliente (dados no servidor) ---------- */
  const accPath = () => `data/users/${session.user.id}/account`;
  let saveTimer=null;
  async function loadAccount(){
    const s=await docRef(accPath()).get(); const d=s.data()||{};
    S.session = { email: session.user.email, exp: Date.now()+864e5*30 };
    S.account = { name: d.name || session.user.user_metadata?.name || session.user.email.split("@")[0], created: d.created || Date.parse(session.user.created_at), favs: d.favs || {products:[],builds:[]}, noTrack: !!d.noTrack };
    S.uid = session.user.id; if(typeof refreshProfile==="function") refreshProfile();
  }
  function saveAccount(){ clearTimeout(saveTimer); saveTimer=setTimeout(()=>{ if(!session) return; const a=S.account; docRef(accPath()).set({name:a.name, created:a.created, favs:a.favs, noTrack:!!a.noTrack}).catch(()=>toast("Não foi possível salvar. Verifique sua conexão.")); }, 600); }
  async function loadProfile(){ if(!session){ profile=null; return; } const {data}=await sb.from("profiles").select("is_owner,name").eq("id",session.user.id).maybeSingle(); profile=data; S.isOwner=!!profile?.is_owner; }

  /* ---------- notificações push (Capacitor) ---------- */
  async function registerPush(){
    const PN = window.Capacitor?.Plugins?.PushNotifications; if(!PN || !session) return;
    try{
      let st = await PN.checkPermissions(); if(st.receive!=="granted") st = await PN.requestPermissions(); if(st.receive!=="granted") return;
      PN.addListener("registration", async t=>{ await sb.from("push_tokens").upsert({token:t.value, user_id:session.user.id, platform:window.Capacitor.getPlatform()}); });
      PN.addListener("pushNotificationActionPerformed", a=>{ const pid=a.notification?.data?.pid; if(pid) location.hash="#/peca/"+pid; });
      await PN.register();
    }catch(e){}
  }

  /* ---------- ações de conta tratadas pelo servidor ---------- */
  const ACTS = new Set(["register","verify","resetdo","resend","login","resetstart","logout","delacc","tracktoggle","inbox"]);
  let pendingMode="verify";
  async function handle(a){
    const val = id => (document.getElementById(id)?.value||"").trim();
    switch(a){
      case "register": {
        const name=val("nm"), email=val("em").toLowerCase(), pw=document.getElementById("pw").value;
        if(name.length<2) return toast("Informe seu nome.");
        if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return toast("Informe um e-mail válido.");
        if(!pwOk(pw)) return toast("A senha precisa de 8+ caracteres, maiúscula, minúscula, número e símbolo.");
        if(!document.getElementById("lgpd").checked) return toast("Aceite a política de privacidade para continuar.");
        const {error}=await sb.auth.signUp({email, password:pw, options:{data:{name, consent_version:"1.0", consent_at:new Date().toISOString()}}});
        if(error) return toast(/registered|exists/i.test(error.message)?"Já existe conta com este e-mail.":"Não foi possível criar a conta. Tente de novo.");
        pendingEmail=email; pendingMode="verify"; accMode="verify"; render(); toast("Enviamos um código para o seu e-mail."); return; }
      case "verify": case "resetdo": {
        const token=val("code"); if(!/^\d{6}$/.test(token)) return toast("Digite o código de 6 dígitos.");
        const {data,error}=await sb.auth.verifyOtp({email:pendingEmail, token, type: a==="verify"?"signup":"recovery"});
        if(error) return toast("Código incorreto ou expirado.");
        if(a==="resetdo"){ const np=document.getElementById("np").value; if(!pwOk(np)) return toast("A nova senha não atende aos requisitos."); const r=await sb.auth.updateUser({password:np}); if(r.error) return toast("Não foi possível trocar a senha."); }
        accMode="login"; track(a==="verify"?"signup":"login"); toast(a==="verify"?"E-mail confirmado. Bem-vindo!":"Senha alterada."); return; }
      case "resend": { const r = pendingMode==="verify" ? await sb.auth.resend({type:"signup", email:pendingEmail}) : await sb.auth.resetPasswordForEmail(pendingEmail); toast(r.error?"Aguarde um pouco para pedir outro código.":"Novo código enviado."); return; }
      case "login": {
        const email=val("em").toLowerCase(), pw=document.getElementById("pw").value;
        const {error}=await sb.auth.signInWithPassword({email,password:pw});
        if(error){ if(/confirm/i.test(error.message)){ pendingEmail=email; pendingMode="verify"; await sb.auth.resend({type:"signup",email}); accMode="verify"; render(); return toast("Confirme seu e-mail: enviamos um novo código."); } return toast("E-mail ou senha incorretos."); }
        track("login"); return; }
      case "resetstart": { const email=val("em").toLowerCase(); await sb.auth.resetPasswordForEmail(email); pendingEmail=email; pendingMode="reset"; accMode="reset2"; render(); toast("Se o e-mail existir, enviamos um código."); return; }
      case "logout": await sb.auth.signOut(); return;
      case "tracktoggle": S.account.noTrack=!S.account.noTrack; saveAccount(); toast(S.account.noTrack?"Análise de uso desativada.":"Análise de uso ativada."); render(); return;
      case "delacc": {
        if(!confirm("Excluir sua conta, favoritos e histórico de uso? Isso não pode ser desfeito.")) return;
        const {data:{session:s}}=await sb.auth.getSession();
        const r=await fetch(cfg.SUPABASE_URL+"/rest/v1/rpc/delete_my_account",{method:"POST",headers:{"apikey":cfg.SUPABASE_ANON_KEY,"Authorization":"Bearer "+s.access_token,"Content-Type":"application/json"},body:"{}"});
        if(!r.ok) return toast("Não foi possível excluir agora. Tente de novo.");
        await sb.auth.signOut(); toast("Conta excluída."); return; }
      case "inbox": return;
    }
  }

  window.NATIVE = { handles:a=>ACTS.has(a), handle, saveAccount, signOut:()=>sb.auth.signOut() };

  /* ---------- substitui o runtime do protótipo ---------- */
  window.claude = { use: async name => name==="db" ? db : name==="user" ? user : name==="sample" ? sample : null };

  sb.auth.onAuthStateChange(async (_ev, s)=>{
    if(typeof S==="undefined") await new Promise(r=>document.readyState==="loading"?addEventListener("DOMContentLoaded",r):setTimeout(r,0));
    session = s;
    if(s){ await loadProfile(); await loadAccount(); registerPush(); if(typeof checkAlerts==="function") checkAlerts(); }
    else { profile=null; S.isOwner=false; S.session=null; S.account=null; }
    if(typeof render==="function") render();
  });
})();

/* ---------- links de loja abrem no navegador do celular (mantém o cookie de afiliado) ---------- */
document.addEventListener("click", e=>{
  const a=e.target.closest('a[target="_blank"]'); if(!a || !window.Capacitor?.isNativePlatform?.()) return;
  const url = typeof safeUrl==="function" ? safeUrl(a.href) : null; e.preventDefault(); if(!url) return;
  const B=window.Capacitor.Plugins?.Browser; if(B) B.open({url, presentationStyle:"popover"}); else window.open(url,"_system");
}, true);
