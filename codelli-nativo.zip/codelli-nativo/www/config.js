// ===== Configuração da Codelli (preencha com os dados do seu projeto Supabase) =====
// Supabase → Project Settings → API. A "anon key" é pública por design: a proteção real está nas regras (RLS) do banco.
window.CODELLI_CONFIG = {
  SUPABASE_URL: "https://SEU-PROJETO.supabase.co",
  SUPABASE_ANON_KEY: "COLE_AQUI_A_ANON_KEY",
  APP: window.CODELLI_APP || "cliente"   // "cliente" ou "dono"
};
