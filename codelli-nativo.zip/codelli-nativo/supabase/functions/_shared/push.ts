// Envio de notificação push via Firebase Cloud Messaging (FCM HTTP v1) — funciona para Android e iPhone.
// Segredo: FCM_SERVICE_ACCOUNT (o JSON da conta de serviço do Firebase, inteiro)
import { create, getNumericDate } from "https://deno.land/x/djwt@v3.0.2/mod.ts";

let cached: { token: string; exp: number } | null = null;
async function accessToken(sa: any): Promise<string> {
  if (cached && cached.exp > Date.now() + 60_000) return cached.token;
  const pem = sa.private_key.replace(/-----[^-]+-----|\n/g, "");
  const key = await crypto.subtle.importKey("pkcs8", Uint8Array.from(atob(pem), c => c.charCodeAt(0)), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const jwt = await create({ alg: "RS256", typ: "JWT" }, { iss: sa.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging", aud: "https://oauth2.googleapis.com/token", iat: getNumericDate(0), exp: getNumericDate(3600) }, key);
  const r = await fetch("https://oauth2.googleapis.com/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}` });
  const j = await r.json(); cached = { token: j.access_token, exp: Date.now() + (j.expires_in ?? 3600) * 1000 }; return cached.token;
}
export async function sendPush(tokens: string[], title: string, body: string, data: Record<string, string> = {}) {
  const raw = Deno.env.get("FCM_SERVICE_ACCOUNT"); if (!raw || !tokens.length) return;
  const sa = JSON.parse(raw); const at = await accessToken(sa);
  await Promise.all(tokens.map(token => fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
    method: "POST", headers: { Authorization: `Bearer ${at}`, "Content-Type": "application/json" },
    body: JSON.stringify({ message: { token, notification: { title, body }, data, apns: { payload: { aps: { sound: "default" } } } } }),
  }).catch(() => null)));
}
