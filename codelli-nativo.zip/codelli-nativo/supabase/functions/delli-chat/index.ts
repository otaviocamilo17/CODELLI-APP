// Codelli — Delli (assistente). A chave da Anthropic fica só aqui no servidor.
// Segredos: ANTHROPIC_API_KEY, (opcional) DELLI_MODEL
import { createClient } from "jsr:@supabase/supabase-js@2";

const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, apikey, content-type", "Access-Control-Allow-Methods": "POST, OPTIONS" };
const MODEL = Deno.env.get("DELLI_MODEL") ?? "claude-haiku-4-5-20251001";
const LIMIT_PER_HOUR = 30;   // por pessoa (ou por IP, se não estiver logada)

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return new Response("Método não permitido", { status: 405, headers: CORS });

  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  // quem está pedindo?
  const jwt = (req.headers.get("Authorization") ?? "").replace("Bearer ", "");
  const { data: u } = await admin.auth.getUser(jwt);
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "anon";
  const key = u?.user?.id ?? "ip:" + ip;

  // limite de uso (contra abuso e conta alta)
  const since = new Date(Date.now() - 3600_000).toISOString();
  const { count } = await admin.from("delli_usage").select("id", { count: "exact", head: true }).eq("user_key", key).gte("created_at", since);
  if ((count ?? 0) >= (u?.user ? LIMIT_PER_HOUR : 10)) return new Response("Limite de mensagens atingido", { status: 429, headers: CORS });
  await admin.from("delli_usage").insert({ user_key: key });

  // valida a entrada
  let body: { turns?: { role: string; content: string }[] };
  try { body = await req.json(); } catch { return new Response("JSON inválido", { status: 400, headers: CORS }); }
  const turns = (body.turns ?? []).slice(-12).filter(t => (t.role === "user" || t.role === "assistant") && typeof t.content === "string")
    .map(t => ({ role: t.role, content: t.content.slice(0, 24000) }));
  if (!turns.length || turns[0].role !== "user") return new Response("Conversa inválida", { status: 400, headers: CORS });

  const upstream = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": Deno.env.get("ANTHROPIC_API_KEY")!, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({ model: MODEL, max_tokens: 900, stream: true, messages: turns }),
  });
  if (!upstream.ok || !upstream.body) return new Response("Delli indisponível", { status: 502, headers: CORS });

  // repassa só o texto, aos poucos (efeito "digitando")
  const reader = upstream.body.getReader(); const dec = new TextDecoder(); const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(ctrl) {
      let buf = "";
      for (;;) {
        const { done, value } = await reader.read(); if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n"); buf = lines.pop() ?? "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try { const ev = JSON.parse(line.slice(6)); if (ev.type === "content_block_delta" && ev.delta?.type === "text_delta") ctrl.enqueue(enc.encode(ev.delta.text)); } catch { /* ignora */ }
        }
      }
      ctrl.close();
    },
  });
  return new Response(stream, { headers: { ...CORS, "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" } });
});
