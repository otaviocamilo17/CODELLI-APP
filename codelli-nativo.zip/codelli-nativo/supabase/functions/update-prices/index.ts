// Codelli — atualização automática de preços + alertas de favoritos.
// Roda a cada 3 horas (ver migrations/0002_agendamento.sql).
// Segredos: CRON_SECRET, ML_CLIENT_ID, ML_CLIENT_SECRET, ML_REFRESH_TOKEN,
//           AMAZON_ACCESS_KEY, AMAZON_SECRET_KEY, AMAZON_PARTNER_TAG (opcionais),
//           FEEDS (opcional: JSON com feeds CSV dos programas de afiliados), FCM_SERVICE_ACCOUNT (push)
import { createClient } from "jsr:@supabase/supabase-js@2";
import { sendPush } from "../_shared/push.ts";

const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 });

/* ---------- Mercado Livre (API oficial) ---------- */
async function mlToken(): Promise<string | null> {
  const id = Deno.env.get("ML_CLIENT_ID"), secret = Deno.env.get("ML_CLIENT_SECRET"); if (!id || !secret) return null;
  const { data: saved } = await admin.from("private_kv").select("value").eq("key", "ml_refresh").maybeSingle();
  const refresh = saved?.value ?? Deno.env.get("ML_REFRESH_TOKEN"); if (!refresh) return null;
  const r = await fetch("https://api.mercadolibre.com/oauth/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "refresh_token", client_id: id, client_secret: secret, refresh_token: refresh }) });
  if (!r.ok) return null; const j = await r.json();
  if (j.refresh_token) await admin.from("private_kv").upsert({ key: "ml_refresh", value: j.refresh_token, updated_at: new Date().toISOString() });
  return j.access_token;
}
async function mlPrice(link: string, token: string): Promise<number | null> {
  const m = link.match(/MLB-?(\d{6,})/i); if (!m) return null;
  const isCatalog = /\/p\/MLB/i.test(link);
  const url = isCatalog ? `https://api.mercadolibre.com/products/MLB${m[1]}` : `https://api.mercadolibre.com/items/MLB${m[1]}`;
  const r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } }); if (!r.ok) return null;
  const j = await r.json();
  const p = isCatalog ? j.buy_box_winner?.price : (j.status === "active" ? j.price : null);
  return typeof p === "number" && p > 0 ? p : null;
}

/* ---------- Amazon (Product Advertising API 5, assinatura AWS SigV4) ---------- */
const te = new TextEncoder();
async function hmac(key: ArrayBuffer | Uint8Array, msg: string) { const k = await crypto.subtle.importKey("raw", key, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]); return new Uint8Array(await crypto.subtle.sign("HMAC", k, te.encode(msg))); }
const hex = (b: ArrayBuffer | Uint8Array) => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, "0")).join("");
async function amazonPrices(asins: string[]): Promise<Record<string, number>> {
  const ak = Deno.env.get("AMAZON_ACCESS_KEY"), sk = Deno.env.get("AMAZON_SECRET_KEY"), tag = Deno.env.get("AMAZON_PARTNER_TAG");
  if (!ak || !sk || !tag || !asins.length) return {};
  const out: Record<string, number> = {};
  for (let i = 0; i < asins.length; i += 10) {
    const host = "webservices.amazon.com.br", region = "us-east-1", path = "/paapi5/getitems", target = "com.amazon.paapi5.v1.ProductAdvertisingAPIv1.GetItems";
    const body = JSON.stringify({ ItemIds: asins.slice(i, i + 10), PartnerTag: tag, PartnerType: "Associates", Marketplace: "www.amazon.com.br", Resources: ["Offers.Listings.Price"] });
    const amz = new Date().toISOString().replace(/[:-]|\.\d{3}/g, ""), date = amz.slice(0, 8);
    const ch = `content-encoding:amz-1.0\ncontent-type:application/json; charset=utf-8\nhost:${host}\nx-amz-date:${amz}\nx-amz-target:${target}\n`;
    const sh = "content-encoding;content-type;host;x-amz-date;x-amz-target";
    const creq = `POST\n${path}\n\n${ch}\n${sh}\n${hex(await crypto.subtle.digest("SHA-256", te.encode(body)))}`;
    const scope = `${date}/${region}/ProductAdvertisingAPI/aws4_request`;
    const sts = `AWS4-HMAC-SHA256\n${amz}\n${scope}\n${hex(await crypto.subtle.digest("SHA-256", te.encode(creq)))}`;
    let k = await hmac(te.encode("AWS4" + sk), date); k = await hmac(k, region); k = await hmac(k, "ProductAdvertisingAPI"); k = await hmac(k, "aws4_request");
    const sig = hex(await hmac(k, sts));
    const r = await fetch(`https://${host}${path}`, { method: "POST", body, headers: { "content-encoding": "amz-1.0", "content-type": "application/json; charset=utf-8", "x-amz-date": amz, "x-amz-target": target,
      Authorization: `AWS4-HMAC-SHA256 Credential=${ak}/${scope}, SignedHeaders=${sh}, Signature=${sig}` } });
    if (!r.ok) continue; const j = await r.json();
    for (const it of j.ItemsResult?.Items ?? []) { const a = it.Offers?.Listings?.[0]?.Price?.Amount; if (typeof a === "number" && a > 0) out[it.ASIN] = a; }
  }
  return out;
}

/* ---------- Feeds CSV dos programas de afiliados (KaBuM!, Pichau, Terabyte...) ---------- */
// FEEDS = [{"store":"kabum","url":"https://.../feed.csv","link_col":"link","price_col":"price","sep":","}]
const clean = (u: string) => { try { const x = new URL(u); return (x.hostname + x.pathname).replace(/\/$/, "").toLowerCase(); } catch { return ""; } };
async function feedPrices(): Promise<Record<string, Record<string, number>>> {
  const out: Record<string, Record<string, number>> = {}; let feeds: any[] = [];
  try { feeds = JSON.parse(Deno.env.get("FEEDS") ?? "[]"); } catch { return out; }
  for (const f of feeds) {
    try {
      const txt = await (await fetch(f.url)).text(); const sep = f.sep ?? ","; const rows = txt.split(/\r?\n/).filter(Boolean);
      const head = rows[0].split(sep).map((h: string) => h.trim().replace(/^"|"$/g, "")); const li = head.indexOf(f.link_col), pi = head.indexOf(f.price_col);
      if (li < 0 || pi < 0) continue; out[f.store] ??= {};
      for (const row of rows.slice(1)) { const c = row.split(sep).map(x => x.trim().replace(/^"|"$/g, "")); const p = Number(String(c[pi]).replace(/[^\d,.]/g, "").replace(/\.(?=\d{3})/g, "").replace(",", ".")); if (p > 0) out[f.store][clean(c[li])] = p; }
    } catch { /* feed fora do ar: tenta na próxima rodada */ }
  }
  return out;
}

Deno.serve(async (req) => {
  if (req.headers.get("x-cron-secret") !== Deno.env.get("CRON_SECRET")) return new Response("Não autorizado", { status: 401 });

  const { data: cfgRow } = await admin.from("docs").select("data").eq("path", "config/affiliates").maybeSingle();
  const cfg: any = cfgRow?.data ?? { stores: {}, products: {} }; cfg.products ??= {};
  const token = await mlToken(); const feeds = await feedPrices();
  const asinOf = (l: string) => l.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})/i)?.[1]?.toUpperCase();
  const asins = Object.values(cfg.products).map((p: any) => p.links?.amazon && asinOf(p.links.amazon)).filter(Boolean) as string[];
  const amz = await amazonPrices([...new Set(asins)]);

  let changed = 0; const now = Date.now(); const newMin: Record<string, number> = {};
  for (const [id, p] of Object.entries<any>(cfg.products)) {
    p.prices ??= {}; let touched = false;
    for (const [store, link] of Object.entries<string>(p.links ?? {})) {
      let price: number | null = null;
      if (store === "ml" && token) price = await mlPrice(link, token);
      else if (store === "amazon") { const a = asinOf(link); price = a ? amz[a] ?? null : null; }
      else price = feeds[store]?.[clean(link)] ?? null;
      if (price && Math.abs((p.prices[store] ?? 0) - price) >= 0.01) { p.prices[store] = Math.round(price * 100) / 100; touched = true; }
    }
    const vals = Object.values<number>(p.prices).filter(v => v > 0);
    if (vals.length) { const mn = Math.min(...vals); newMin[id] = mn; p.hist ??= []; const last = p.hist[p.hist.length - 1]; if (!last || Math.abs(last.p - mn) >= 1) p.hist.push({ t: now, p: mn }); p.hist = p.hist.slice(-60); }
    if (touched) { p.updated = now; changed++; }
  }
  if (changed) await admin.from("docs").upsert({ path: "config/affiliates", parent: "config", data: cfg });

  /* ---------- alertas dos favoritos ---------- */
  let alerts = 0;
  const { data: accs } = await admin.from("docs").select("path,data").like("path", "data/users/%/account");
  for (const row of accs ?? []) {
    const uid = row.path.split("/")[2]; const a: any = row.data; const f = a.favs ?? {}; f.watch ??= {}; f.notifs ??= [];
    const fresh: any[] = [];
    for (const id of f.products ?? []) {
      const w = f.watch[id]; const cur = newMin[id]; if (!w || !cur || w.alert === false) continue;
      const diff = cur - w.last;
      if (Math.abs(diff) >= Math.max(5, w.last * 0.01)) { fresh.push({ pid: id, type: diff < 0 ? "down" : "up", from: w.last, to: cur, at: now, read: false }); w.last = cur; }
      if (w.target && cur <= w.target && !w.hit) { fresh.push({ pid: id, type: "target", from: w.target, to: cur, at: now, read: false }); w.hit = true; }
      if (w.target && cur > w.target) w.hit = false;
    }
    if (!fresh.length) continue;
    f.notifs = fresh.concat(f.notifs).slice(0, 60); a.favs = f;
    await admin.from("docs").upsert({ path: row.path, parent: row.path.split("/").slice(0, -1).join("/"), data: a });
    const drop = fresh.find(n => n.type !== "up");
    if (drop) {
      const { data: toks } = await admin.from("push_tokens").select("token").eq("user_id", uid);
      await sendPush((toks ?? []).map(t => t.token), drop.type === "target" ? "🎯 Chegou no seu preço!" : "🔥 Baixou! Corre!",
        `Um favorito seu agora custa ${brl(drop.to)}.`, { pid: drop.pid });
      alerts++;
    }
  }
  return Response.json({ produtos_atualizados: changed, alertas_enviados: alerts });
});
