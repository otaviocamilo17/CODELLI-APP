-- =====================================================================
-- Codelli — banco de dados (Supabase / Postgres)
-- Rode no Supabase: SQL Editor → cole tudo → Run.
-- Todas as tabelas têm RLS (Row Level Security): cada regra é checada
-- no servidor, então mesmo alguém com o app adulterado não passa.
-- =====================================================================

-- ---------- perfis (1 por conta) ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  name text,
  is_owner boolean not null default false,
  consent_version text,
  consent_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

-- função auxiliar: o usuário atual é o dono?
create or replace function public.is_owner() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select is_owner from public.profiles where id = auth.uid()), false)
$$;

create policy "perfil: dono do perfil lê" on public.profiles for select using (id = auth.uid() or public.is_owner());
create policy "perfil: usuário edita o próprio" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
-- o usuário só pode mudar o próprio nome; "is_owner" nunca pode ser alterado pelo app
revoke update on public.profiles from authenticated, anon;
grant update (name) on public.profiles to authenticated;

-- cria o perfil automaticamente no cadastro
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, name, consent_version, consent_at)
  values (new.id, new.email, new.raw_user_meta_data->>'name', new.raw_user_meta_data->>'consent_version', (new.raw_user_meta_data->>'consent_at')::timestamptz);
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- ---------- documentos (config de links/preços, fotos, dados de cada cliente) ----------
create table if not exists public.docs (
  path text primary key check (char_length(path) <= 300),
  parent text not null,
  data jsonb not null check (pg_column_size(data) <= 400000),
  updated_at timestamptz not null default now()
);
create index if not exists docs_parent_idx on public.docs(parent);
alter table public.docs enable row level security;

-- leitura: config e imagens são públicas; dados de usuário só do próprio usuário (e do dono)
create policy "docs: leitura" on public.docs for select using (
  path like 'config/%' or path like 'images/%'
  or path like ('data/users/' || auth.uid()::text || '/%')
  or public.is_owner()
);
-- escrita: config e imagens só o dono; dados de usuário só o próprio usuário
create policy "docs: inserir" on public.docs for insert with check (
  ((path like 'config/%' or path like 'images/%') and public.is_owner())
  or path like ('data/users/' || auth.uid()::text || '/%')
);
create policy "docs: atualizar" on public.docs for update using (
  ((path like 'config/%' or path like 'images/%') and public.is_owner())
  or path like ('data/users/' || auth.uid()::text || '/%')
);
create policy "docs: apagar" on public.docs for delete using (
  ((path like 'config/%' or path like 'images/%') and public.is_owner())
  or path like ('data/users/' || auth.uid()::text || '/%')
);
create or replace function public.touch_updated_at() returns trigger language plpgsql as $$ begin new.updated_at = now(); return new; end $$;
drop trigger if exists docs_touch on public.docs;
create trigger docs_touch before update on public.docs for each row execute function public.touch_updated_at();

-- ---------- visitantes e eventos (o "Codelli Dono" lê daqui) ----------
create table if not exists public.visitors (
  uid uuid primary key references auth.users(id) on delete cascade,
  acct text, name text, ua text,
  first_seen timestamptz not null default now(),
  last_seen timestamptz not null default now()
);
alter table public.visitors enable row level security;
create policy "visitors: próprio grava" on public.visitors for insert with check (uid = auth.uid());
create policy "visitors: próprio atualiza" on public.visitors for update using (uid = auth.uid());
create policy "visitors: dono lê tudo" on public.visitors for select using (uid = auth.uid() or public.is_owner());

create table if not exists public.events (
  id text primary key check (char_length(id) <= 40),
  uid uuid not null references auth.users(id) on delete cascade,
  type text not null check (type in ('view','product','search','click','fav','unfav','build_saved','build_shared','build_imported','autobuild','delli','delli_build','signup','login','alert','security')),
  acct text, name text, pid text, store text, price numeric, q text,
  owner_action boolean not null default false,
  raw jsonb not null check (pg_column_size(raw) <= 4000),
  created_at timestamptz not null default now()
);
create index if not exists events_uid_idx on public.events(uid, created_at desc);
create index if not exists events_type_idx on public.events(type, created_at desc);
create index if not exists events_pid_idx on public.events(pid) where pid is not null;
alter table public.events enable row level security;
create policy "events: próprio grava" on public.events for insert with check (uid = auth.uid());
create policy "events: dono lê tudo" on public.events for select using (uid = auth.uid() or public.is_owner());
create policy "events: próprio apaga" on public.events for delete using (uid = auth.uid());

-- trava contra abuso: no máximo 600 eventos por hora por usuário
create or replace function public.events_rate_limit() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.events where uid = new.uid and created_at > now() - interval '1 hour') >= 600 then
    raise exception 'rate limit';
  end if;
  new.created_at = now();  -- horário sempre do servidor
  return new;
end $$;
drop trigger if exists events_rl on public.events;
create trigger events_rl before insert on public.events for each row execute function public.events_rate_limit();

-- relatórios prontos para o dono (abra no Table Editor ou SQL)
create or replace view public.rel_cliques_por_produto with (security_invoker = true) as
  select pid, max(raw->>'pname') as produto, count(*) as cliques, sum(price) as valor_clicado,
         count(*) filter (where (raw->>'direct')::boolean) as pelos_meus_links
  from public.events where type = 'click' and not owner_action group by pid order by cliques desc;
create or replace view public.rel_buscas with (security_invoker = true) as
  select q as termo, count(*) as vezes, count(*) filter (where (raw->>'results')::int = 0) as sem_resultado
  from public.events where type = 'search' and not owner_action group by q order by vezes desc;
create or replace view public.rel_clientes with (security_invoker = true) as
  select v.uid, p.name, p.email, v.first_seen, v.last_seen,
         count(e.*) filter (where e.type='click') as cliques,
         coalesce(sum(e.price) filter (where e.type='click'),0) as valor_clicado
  from public.visitors v left join public.profiles p on p.id = v.uid left join public.events e on e.uid = v.uid
  group by v.uid, p.name, p.email, v.first_seen, v.last_seen order by cliques desc;

-- ---------- notificações push ----------
create table if not exists public.push_tokens (
  token text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  platform text,
  created_at timestamptz not null default now()
);
alter table public.push_tokens enable row level security;
create policy "push: próprio" on public.push_tokens for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------- uso da Delli (limite por pessoa) ----------
create table if not exists public.delli_usage (
  id bigserial primary key,
  user_key text not null,
  created_at timestamptz not null default now()
);
create index if not exists delli_usage_idx on public.delli_usage(user_key, created_at desc);
alter table public.delli_usage enable row level security; -- só a função do servidor (service role) acessa

-- ---------- excluir a própria conta (LGPD) ----------
create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  if auth.uid() is null then raise exception 'não autenticado'; end if;
  delete from public.docs where path like ('data/users/' || auth.uid()::text || '/%');
  delete from auth.users where id = auth.uid();   -- apaga perfil, eventos, visitantes e tokens em cascata
end $$;
revoke all on function public.delete_my_account() from public;
grant execute on function public.delete_my_account() to authenticated;

-- ---------- tempo real para preços e fotos ----------
alter publication supabase_realtime add table public.docs;

-- =====================================================================
-- DEPOIS DE CRIAR A SUA CONTA NO APP, rode isto trocando o e-mail para virar dono:
--   update public.profiles set is_owner = true where email = 'seu-email@exemplo.com';
-- =====================================================================

-- ---------- segredos internos (tokens de API que se renovam). Sem políticas = ninguém do app lê ----------
create table if not exists public.private_kv (key text primary key, value text not null, updated_at timestamptz not null default now());
alter table public.private_kv enable row level security;
