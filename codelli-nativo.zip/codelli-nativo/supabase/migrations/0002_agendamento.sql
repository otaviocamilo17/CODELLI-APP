-- Atualização automática de preços a cada 3 horas (pg_cron + pg_net).
-- Supabase → Database → Extensions: ative "pg_cron" e "pg_net". Depois rode:
-- Troque SEU-PROJETO e a CHAVE_DO_CRON (a mesma que você colocar no segredo CRON_SECRET).
select cron.schedule(
  'codelli-atualiza-precos',
  '0 */3 * * *',
  $$ select net.http_post(
       url := 'https://SEU-PROJETO.supabase.co/functions/v1/update-prices',
       headers := jsonb_build_object('Content-Type','application/json','x-cron-secret','CHAVE_DO_CRON'),
       body := '{}'::jsonb) $$
);
