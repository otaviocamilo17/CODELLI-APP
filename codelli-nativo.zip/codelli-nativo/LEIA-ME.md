# Codelli — versão nativa (App Store e Play Store) + servidor

Este pacote transforma o protótipo da Codelli em **dois apps de verdade**:

- **Codelli**: o app dos clientes (`com.codelli.app`)
- **Codelli Dono**: o seu painel, em um app separado (`com.codelli.dono`)

Os dois usam o **mesmo servidor no Supabase**: login com e-mail real, banco de dados, Delli com chave protegida, preços automáticos e notificações push.

```
codelli-nativo/
├─ www/                      ← o app (mesmo visual e funções do protótipo)
│  ├─ index.html
│  ├─ config.js              ← você cola aqui a URL e a chave pública do Supabase
│  ├─ backend.js             ← ponte entre o app e o servidor
│  └─ vendor/supabase.js
├─ supabase/
│  ├─ migrations/0001_codeli.sql       ← banco + regras de segurança
│  ├─ migrations/0002_agendamento.sql  ← preços a cada 3 horas
│  └─ functions/
│     ├─ delli-chat/          ← a Delli (chave da IA fica só no servidor)
│     ├─ update-prices/      ← preços automáticos + alertas de favoritos
│     └─ _shared/push.ts     ← envio de notificação no celular
├─ capacitor.config.json
├─ package.json
└─ scripts/prepare-dono.mjs  ← gera o app Codelli Dono
```

---

## Passo 1 — Contas que você precisa

| Conta | Para quê | Custo |
|---|---|---|
| supabase.com | Servidor, banco e login | Grátis para começar |
| console.anthropic.com | Chave da IA da Delli | Paga por uso |
| firebase.google.com | Notificações push (Android e iPhone) | Grátis |
| developers.mercadolivre.com.br | Preços automáticos do Mercado Livre | Grátis |
| associados.amazon.com.br | Links e preços da Amazon | Grátis |
| play.google.com/console | Publicar no Android | US$ 25, uma única vez |
| developer.apple.com | Publicar no iPhone | US$ 99 por ano |
| resend.com (ou outro SMTP) | Enviar os e-mails de código | Grátis até um limite |

## Passo 2 — Banco de dados (Supabase)

1. Crie um projeto em supabase.com e escolha a região **São Paulo**.
2. Abra **SQL Editor**, cole o arquivo `supabase/migrations/0001_codeli.sql` inteiro e clique em **Run**.
3. Vá em **Authentication → Sign In / Providers → Email** e:
   - deixe **Confirm email** ligado;
   - ative **Leaked password protection**;
   - em **Attack Protection**, ative o **CAPTCHA** (Cloudflare Turnstile), que barra robôs criando contas.
4. Vá em **Authentication → Email Templates**. Em **Confirm signup** e em **Reset Password**, troque o link pelo código:
   ```html
   <h2>Seu código Codelli</h2>
   <p>Use este código no app: <b style="font-size:24px">{{ .Token }}</b></p>
   <p>Ele vale por pouco tempo. Se não foi você, ignore este e-mail.</p>
   ```
5. Vá em **Authentication → SMTP Settings** e conecte o Resend. O envio padrão do Supabase só aguenta poucos e-mails por hora.
6. Abra **Project Settings → API**, copie a **Project URL** e a **anon public key** e cole em `www/config.js`.
   - A anon key é pública por natureza. Quem protege os dados são as regras do banco que você rodou no item 2.

## Passo 3 — Funções do servidor

Instale a CLI do Supabase (https://supabase.com/docs/guides/cli) e, dentro desta pasta, rode:

```bash
supabase login
supabase link --project-ref SEU-PROJETO
supabase functions deploy delli-chat
supabase functions deploy update-prices --no-verify-jwt

supabase secrets set ANTHROPIC_API_KEY=sk-ant-...
supabase secrets set CRON_SECRET=uma-senha-longa-e-aleatoria
supabase secrets set ML_CLIENT_ID=... ML_CLIENT_SECRET=... ML_REFRESH_TOKEN=...
supabase secrets set AMAZON_ACCESS_KEY=... AMAZON_SECRET_KEY=... AMAZON_PARTNER_TAG=seutag-20
supabase secrets set FCM_SERVICE_ACCOUNT="$(cat firebase-conta-de-servico.json)"
```

- **Delli:** usa o Claude Haiku 4.5, rápido e barato. Para respostas mais elaboradas, rode `supabase secrets set DELLI_MODEL=claude-sonnet-5-5`.
- **Limite da Delli:** 30 mensagens por hora por pessoa logada e 10 por visitante. Os valores ficam no topo de `delli-chat/index.ts`.
- **Mercado Livre:** crie um app em developers.mercadolivre.com.br e faça a autorização uma vez para obter o `refresh_token`. Depois o servidor renova o token sozinho.
- **Amazon:** a API de preços só libera depois de 3 vendas qualificadas em 180 dias como afiliado. Antes disso, os preços da Amazon continuam pelo painel.
- **KaBuM!, Pichau e Terabyte:** quando entrar no programa de afiliados de cada uma, peça o link do **feed de produtos (CSV)** e configure assim:
  ```bash
  supabase secrets set FEEDS='[{"store":"kabum","url":"https://...csv","link_col":"link","price_col":"price","sep":","}]'
  ```

## Passo 4 — Preços automáticos a cada 3 horas

1. Vá em **Database → Extensions** e ative **pg_cron** e **pg_net**.
2. Abra `supabase/migrations/0002_agendamento.sql`, troque `SEU-PROJETO` e `CHAVE_DO_CRON` (a mesma do `CRON_SECRET`) e rode no SQL Editor.

A cada rodada, o servidor:
- atualiza os preços e o histórico de cada produto;
- confere os favoritos de cada cliente;
- manda a notificação **"🔥 Baixou! Corre!"** no celular de quem favoritou;
- muda os preços na hora em todos os celulares com o app aberto.

## Passo 5 — Virar dono

1. Instale o app no seu celular, ou abra `www/index.html` num servidor local, e crie a sua conta.
2. No SQL Editor, rode:
   ```sql
   update public.profiles set is_owner = true where email = 'SEU-EMAIL';
   ```

Pronto: o painel do dono, os links, as fotos e a central de segurança passam a aparecer para você. Ninguém mais consegue virar dono pelo app, porque o banco bloqueia a mudança desse campo.

## Passo 6 — Gerar os apps

Você precisa do **Node.js 20 ou mais novo**, do **Android Studio** e, para iPhone, de **um Mac com Xcode**. Sem Mac, dá para usar o Codemagic ou o Ionic Appflow, que compilam o app de iPhone na nuvem.

```bash
npm install
npx cap add android
npx cap add ios
npx cap sync
npx cap open android      # Build → Generate Signed Bundle (.aab) → envia à Play Store
npx cap open ios          # Product → Archive → envia à App Store
```

- **Push:** no Firebase, adicione os apps Android e iOS. Coloque `google-services.json` em `android/app/` e `GoogleService-Info.plist` no projeto iOS. No Xcode, ative **Push Notifications**.
- **Ícones e tela de abertura:** `npx @capacitor/assets generate`, com o seu símbolo em `assets/icon.png` (1024×1024).

### App Codelli Dono

```bash
npm run dono:prepare      # cria ../codelli-dono com nome e ID próprios
cd ../codelli-dono && npm install && npx cap add android && npx cap add ios && npx cap sync
```

O app do dono abre direto no painel. Ele pode ser publicado como **app interno**: no Android, use a faixa de teste interno da Play Store; no iPhone, use o TestFlight. Assim ele não aparece para o público.

## Passo 7 — Checklist para aprovação nas lojas

- [ ] **Política de privacidade** publicada num site, por exemplo uma página no site da Codelli, com o mesmo texto da tela "Privacidade e termos".
- [ ] **Exclusão de conta dentro do app:** já existe em Minha conta → Excluir conta. É obrigatória na Apple e no Google.
- [ ] **Play Store → Segurança dos dados** e **App Store → Privacidade:** declare nome, e-mail, histórico de navegação no app (buscas e cliques) e identificadores. Finalidade: funcionalidade do app e análise. Não declare venda de dados, porque eles não são vendidos.
- [ ] **Links de afiliado:** o aviso já aparece no app. Compras de produtos físicos em sites de lojas são permitidas pelas duas lojas.
- [ ] **Conta de teste para os revisores:** crie uma conta comum e informe o login e a senha no formulário de envio.
- [ ] **Classificação etária:** Livre. Preencha o questionário de cada loja.
- [ ] **Capturas de tela:** iPhone 6,9", Android celular e, se quiser, tablet.

## Segurança — o que está ativo

| Camada | Como funciona |
|---|---|
| Regras no servidor (RLS) | Cada leitura e gravação é checada no banco. Clientes só veem os próprios dados, só o dono vê os registros de todos e só o dono muda links, preços e fotos. |
| Dono à prova de fraude | O campo `is_owner` não pode ser alterado pelo app. Só você muda pelo painel do Supabase. |
| Senhas | Ficam com o Supabase Auth (bcrypt), com proteção contra senhas vazadas e CAPTCHA no cadastro. |
| Chaves secretas | As chaves da Anthropic, do Mercado Livre, da Amazon e do Firebase ficam só no servidor. Nunca vão para dentro do app. |
| Limites contra abuso | A Delli tem limite por hora por pessoa e por IP. Os registros de uso são limitados a 600 por hora por pessoa. O Supabase também limita tentativas de login. |
| Conteúdo | Tudo que vem do banco é limpo antes de aparecer. Links só https das 5 lojas. Política de conteúdo (CSP) no app. Tamanho máximo para fotos e documentos. |
| LGPD | Consentimento no cadastro, opção de desligar a análise de uso, exportação de dados e exclusão de conta que apaga tudo em cascata. |

**Recomendado depois do lançamento:**
- Ative **MFA** (código no celular) na sua conta do Supabase e no login de dono.
- Ative os **backups diários** do Supabase (plano Pro).
- Rode `npm audit` a cada atualização.

## Onde ver os registros de cada cliente

No Supabase, abra **Table Editor**:

| Tabela ou visão | O que mostra |
|---|---|
| `profiles` | Todas as contas: nome, e-mail, data e consentimento |
| `events` | Cada ação de cada cliente: busca, produto visto, clique para comprar, pergunta à Delli |
| `rel_clientes` | Ranking de clientes por cliques e valor clicado |
| `rel_cliques_por_produto` | O que mais clicam e quantos cliques foram pelos seus links |
| `rel_buscas` | O que mais buscam e o que buscam e não acham |

O app **Codelli Dono** mostra tudo isso com gráficos, direto no celular.
