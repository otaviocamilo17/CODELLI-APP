// Cria a pasta ../codelli-dono: o mesmo app, aberto direto no painel do dono, com outro ícone/nome na loja.
import { cpSync, writeFileSync, readFileSync, rmSync, existsSync } from "node:fs";
const dest = new URL("../../codelli-dono/", import.meta.url).pathname;
if (existsSync(dest)) rmSync(dest, { recursive: true });
cpSync(new URL("../", import.meta.url).pathname, dest, { recursive: true, filter: p => !/node_modules|android|ios|codelli-dono|supabase/.test(p) });
writeFileSync(dest + "www/app-cliente.js", 'window.CODELLI_APP = "dono";\n');
const cfg = JSON.parse(readFileSync(dest + "capacitor.config.json", "utf8"));
cfg.appId = "com.codelli.dono"; cfg.appName = "Codelli Dono";
writeFileSync(dest + "capacitor.config.json", JSON.stringify(cfg, null, 2));
const pkg = JSON.parse(readFileSync(dest + "package.json", "utf8")); pkg.name = "codelli-dono"; delete pkg.scripts["dono:prepare"];
writeFileSync(dest + "package.json", JSON.stringify(pkg, null, 2));
console.log("Pronto! Projeto do app do dono criado em", dest);
